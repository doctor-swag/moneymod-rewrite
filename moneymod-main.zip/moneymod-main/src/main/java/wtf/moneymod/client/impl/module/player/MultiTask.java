package wtf.moneymod.client.impl.module.player;

import wtf.moneymod.client.impl.module.Module;

@Module.Register( label = "MultiTask", desc = "Allows you to interact with blocks and use items at the same time", cat = Module.Category.PLAYER )
public class MultiTask extends Module
{

}
