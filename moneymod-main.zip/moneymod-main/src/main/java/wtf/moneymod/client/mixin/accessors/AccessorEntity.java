package wtf.moneymod.client.mixin.accessors;

public interface AccessorEntity
{
    boolean isInWeb( );
    void setInWeb( boolean state );
}