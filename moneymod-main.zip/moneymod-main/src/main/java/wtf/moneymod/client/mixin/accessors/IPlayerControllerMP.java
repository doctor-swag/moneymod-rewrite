package wtf.moneymod.client.mixin.accessors;

public interface IPlayerControllerMP {

    void setBlockHitDelay(int delay);

    void setIsHittingBlock(boolean isHittingBlock);

}
