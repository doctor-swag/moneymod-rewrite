package wtf.moneymod.client.api.management;

/**
 * @author cattyn
 * @since 11/02/21
 */

@FunctionalInterface
public interface IManager<T> {

    T register();

}
