package wtf.moneymod.client.api.events;

import net.minecraft.entity.Entity;
import net.minecraftforge.fml.common.eventhandler.Cancelable;
import wtf.moneymod.eventhandler.event.Event;

@Cancelable
public class PushEvent
        extends Event {

}
