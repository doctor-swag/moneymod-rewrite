package wtf.moneymod.client.api.management.impl;

import wtf.moneymod.client.api.management.IManager;

/**
 * @author yoursleep
 * @since 02 November 2021
 */
public class NotificationManagement implements IManager<NotificationManagement> {

    @Override public NotificationManagement register() {
        return this;
    }
    //НАЙС КОД !!
}
