package wtf.moneymod.client.api.events;

import wtf.moneymod.eventhandler.event.Event;
import wtf.moneymod.eventhandler.event.enums.Era;

public class RenderNameTagEvent extends Event {

    public RenderNameTagEvent() { }

}
