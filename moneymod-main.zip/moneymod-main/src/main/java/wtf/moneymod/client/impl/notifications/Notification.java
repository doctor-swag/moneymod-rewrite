package wtf.moneymod.client.impl.notifications;

/**
 * @author yoursleep
 * @since 02 November 2021
 */

public class Notification {

}